package Project.DailyJournalApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DailyJournalAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DailyJournalAppApplication.class, args);
	}

}
